<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>DockClass</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="20"/>
        <source>SCP Dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="42"/>
        <source>SCP input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="61"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Band calc&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="81"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Tools&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="101"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocessing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="121"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="141"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Postprocessing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="174"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;User manual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="207"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Online help&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Download images&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="271"/>
        <source> Training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="285"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Input file path&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="292"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Open a training input&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Create a new training input&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="336"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Refresh list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1311"/>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="359"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Band set&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="379"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an image&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="386"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open a file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="422"/>
        <source> Input image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="465"/>
        <source> SCP news</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="486"/>
        <source>Classification dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="519"/>
        <source> ROI Signature list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="557"/>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="562"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1648"/>
        <source>MC ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1664"/>
        <source>C ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="986"/>
        <source>C Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1372"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="609"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add highlighted items to scatter plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="702"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="647"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import spectral signatures &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1972"/>
        <source>Import library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="670"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export highlighted spectral signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="696"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Delete highlighted items&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="719"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate signatures for highlighted items&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="742"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Merge highlighted spectral signatures obtaining the average signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="765"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add highlighted signatures to spectral signature plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="824"/>
        <source>ROI creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="841"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display a vegetation index value with the cursor&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="844"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="854"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a vegetation index&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="858"/>
        <source>NDVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="863"/>
        <source>EVI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="868"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="876"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Custom expression (e.g. bandset#b4 / bandset#b3 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="898"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The class name of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="901"/>
        <source>C 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="923"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The macroclass ID of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="948"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The macroclass name of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="951"/>
        <source>MC 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1367"/>
        <source>MC Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1037"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The class ID of the ROI signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1060"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Undo ROI save&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1096"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signature to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1099"/>
        <source>Calculate sig.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1109"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Save temporary ROI to training input&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1138"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically refresh the temporary ROI, as the parameters change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1141"/>
        <source>Automatic refresh ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1159"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band number&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1178"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate temporary ROI only on one band&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1181"/>
        <source>Rapid ROI band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1190"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically calculate signature plot of temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1193"/>
        <source>Automatic  plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1220"/>
        <source> Macroclasses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1255"/>
        <source>Classification style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1305"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1401"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qml file path&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Reset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1437"/>
        <source>Load qml</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1444"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Select qml style&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1483"/>
        <source> Classification algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1532"/>
        <source>Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1551"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a classification algorithm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1555"/>
        <source>Minimum Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1560"/>
        <source>Maximum Likelihood</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1565"/>
        <source>Spectral Angle Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1585"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a classification threshold for all signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1601"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab Signature threshold&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1690"/>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1745"/>
        <source>Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1645"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the ID of macroclasses for the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1661"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the ID of classes for the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1684"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab Algorithm band weight&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1725"/>
        <source> Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1752"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the Land Cover Signature Classification is used&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1755"/>
        <source>LCS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1762"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the selected Algorithm is used for unclassified pixels of the Land Cover Signature Classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1765"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1772"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the selected Algorithm is used only for class overlapping pixels of the Land Cover Signature Classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1775"/>
        <source>only overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1782"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open tab LCS threshold&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1821"/>
        <source> Land Cover Signature Classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1849"/>
        <source> Classification output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1873"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an optional mask vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1876"/>
        <source>Apply mask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Path of the optional mask shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1928"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a classification shapefile after the classification process&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1931"/>
        <source>Create vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1938"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate a classification report&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1941"/>
        <source>Classification report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1952"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, the rasters calculated by the classification algorithm (one per signature) are saved along with the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1955"/>
        <source>Save algorithm files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_dock_class.ui" line="1966"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Run&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScatterPlot</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="20"/>
        <source>SCP: Scatter Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="68"/>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="73"/>
        <source>MC ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="78"/>
        <source>MC Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="83"/>
        <source>C ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="88"/>
        <source>C Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="93"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="150"/>
        <source> Scatter raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="168"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="175"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="201"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate and display scatter raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="224"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate and save to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="275"/>
        <source>x=0.000000 y=0.000000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="284"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically fit the plot to data&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save the plot to file (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="348"/>
        <source> Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="366"/>
        <source>Colormap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="385"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a colormap&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="395"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set colormap for highlighted spectral plots&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="428"/>
        <source>Extent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="441"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select extent of scatter raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="448"/>
        <source>same as display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="453"/>
        <source>same as image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="467"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create selection polygons&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="496"/>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="503"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select polygon color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="516"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove selection polygons&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="546"/>
        <source>Band Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="571"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Band Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="600"/>
        <source>Band X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="625"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Band X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="648"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use custom decimal precision&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="651"/>
        <source>Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="658"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select decimal precision:&lt;/p&gt;&lt;p&gt;4 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−4&lt;/span&gt;&lt;/p&gt;&lt;p&gt;3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−3&lt;/span&gt;&lt;/p&gt;&lt;p&gt;2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;1 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;−1&lt;/span&gt;&lt;/p&gt;&lt;p&gt;0 = 1&lt;/p&gt;&lt;p&gt;-1 = 10&lt;/p&gt;&lt;p&gt;-2 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;2&lt;/span&gt;&lt;/p&gt;&lt;p&gt;-3 = 10^&lt;span style=&quot; vertical-align:super;&quot;&gt;3&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="665"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="670"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="675"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="680"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="685"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="690"/>
        <source>-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="695"/>
        <source>-2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="700"/>
        <source>-3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="725"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="731"/>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="748"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="771"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from the current display extent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="794"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate scatter plot from entire image&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_scatter_plot.ui" line="843"/>
        <source> Scatter list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SemiAutomaticClassificationPlugin</name>
    <message>
        <location filename="input.py" line="140"/>
        <source>RGB = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="155"/>
        <source>ROI     </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="175"/>
        <source>Preview </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15199"/>
        <source>Semi-Automatic Classification Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="70"/>
        <source>Download images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="90"/>
        <source>Landsat download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3236"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preprocess images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3239"/>
        <source>Preprocess images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3249"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Load images in QGIS after download&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3252"/>
        <source>Load bands in QGIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3262"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download images from list only if the corresponding previews are loaded in QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3265"/>
        <source>Only if preview in Layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="153"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Download (from &lt;/span&gt;&lt;a href=&quot;http://aws.amazon.com/public-data-sets/landsat&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Amazon Web Services&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;https://earthengine.google.com/datasets&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;Google Earth Engine&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;, &lt;/span&gt;&lt;a href=&quot;http://earthexplorer.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;USGS  EarthExplorer&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13855"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Run&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15009"/>
        <source>Import library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3340"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export download links to a text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2526"/>
        <source> Search area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7934"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set area in the map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7855"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lower right X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7885"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lower right Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7865"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left X&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7875"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left Y&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2609"/>
        <source>LR X (Lon)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2622"/>
        <source>UL Y (Lat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2635"/>
        <source>UL X (Lon)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2648"/>
        <source>LR Y (Lat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7993"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Show / hide area&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7996"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2724"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Find images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2744"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2834"/>
        <source>yyyy-MM-dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2790"/>
        <source>Max cloud cover (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2803"/>
        <source>Satellites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2847"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2860"/>
        <source>Date from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2873"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a satellite&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1793"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximum cloud cover percentage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2930"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt; Search&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2976"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2998"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter images&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="750"/>
        <source>Landsat images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13514"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14033"/>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3067"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display preview of highlighted images in map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14603"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Reset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3131"/>
        <source> Image list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3160"/>
        <source>ImageID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3165"/>
        <source>AcquisitionDate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3170"/>
        <source>CloudCover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="891"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="896"/>
        <source>Row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3185"/>
        <source>min_lat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3190"/>
        <source>min_lon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3195"/>
        <source>max_lat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3200"/>
        <source>max_lon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="921"/>
        <source>USGScollection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3210"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3215"/>
        <source>collection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2086"/>
        <source>Download options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2094"/>
        <source>Band 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2131"/>
        <source>Band 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2104"/>
        <source>Band 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2151"/>
        <source>Band 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2221"/>
        <source>Band 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2231"/>
        <source>Band 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2161"/>
        <source>Band 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1048"/>
        <source>Band QA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2141"/>
        <source>Band 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1068"/>
        <source>Band 8 (Panchromatic)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2191"/>
        <source>Band 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2201"/>
        <source>Band 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13232"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Select all&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1137"/>
        <source> Landsat 8 bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2436"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, remember user name and password locally in QGIS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2439"/>
        <source>remember</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2449"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Password&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2456"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1197"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login &lt;a href=&quot;https://ers.cr.usgs.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://ers.cr.usgs.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2492"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;User name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2499"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1231"/>
        <source>Sentinel-2 download </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1412"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login Sentinels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3205"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1471"/>
        <source>https://scihub.copernicus.eu/s2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1560"/>
        <source> Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1855"/>
        <source>Sentinel images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="1934"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display overview of highlighted images in map&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2007"/>
        <source>ImageName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2012"/>
        <source>Granule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2022"/>
        <source>Zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2052"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2062"/>
        <source>GranulePreview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2171"/>
        <source>Band 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2181"/>
        <source>Band 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2211"/>
        <source>Band 8A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2280"/>
        <source> Sentinel-2 bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2339"/>
        <source> Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2428"/>
        <source>ASTER download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2479"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Login &lt;a href=&quot;https://urs.earthdata.nasa.gov&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;https://urs.earthdata.nasa.gov&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="2892"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Maximum cloud cover percentage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3034"/>
        <source>ASTER images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3175"/>
        <source>ImageDisplayID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3180"/>
        <source>DayNightFlag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;Download (from &lt;/span&gt;&lt;a href=&quot;https://lpdaac.usgs.gov/data_access/data_pool&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#ffffff;&quot;&gt;NASA EOSDIS Land Processes DAAC&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3378"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3398"/>
        <source>Multiple ROI creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3424"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Minimum distance between points&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3461"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Size of a grid cell within points are created randomly&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3496"/>
        <source>Create random points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3516"/>
        <source>Create points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3529"/>
        <source>Number of points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3557"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Number of points created randomly&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3576"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create points&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3596"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create random points with a minimum distance&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3599"/>
        <source>min distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3606"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create random points inside each cell of a grid with this size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3609"/>
        <source>inside grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3649"/>
        <source> Point coordinates and ROI definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3669"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3674"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5278"/>
        <source>MC ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5283"/>
        <source>MC Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5288"/>
        <source>C ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5293"/>
        <source>C Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3699"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3704"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3709"/>
        <source>Dist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3714"/>
        <source>Rapid ROI band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12827"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3785"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export point list to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3821"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Import point list from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3876"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signatures to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4264"/>
        <source>Calculate sig.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13950"/>
        <source> Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3947"/>
        <source>Import signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3965"/>
        <source>Import library file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="3985"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a file: SCP file (*.scp) ; USGS library (*.asc) ; ASTER library (*.txt) ; CSV (*.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13212"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span &gt;Open a file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4039"/>
        <source>Import shapefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7277"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open a file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4085"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a shapefile (*.shp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9319"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a reference shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14162"/>
        <source>C Info field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4175"/>
        <source> Shapefile fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14231"/>
        <source>C ID field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14254"/>
        <source>MC ID field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14267"/>
        <source>MC Info field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4241"/>
        <source>  Import shapefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4261"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add ROI spectral signature to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4274"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import shapefile&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4327"/>
        <source>Download USGS Spectral Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4370"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a chapter&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4386"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a library&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4421"/>
        <source>Import spectral library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4431"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import spectral library&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4459"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4479"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;USGS Spectral Library downloaded from &lt;a href=&quot;http://speclab.cr.usgs.gov/spectral-lib.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://speclab.cr.usgs.gov/spectral-lib.html&lt;/span&gt;&lt;/a&gt;.&lt;br/&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Reference&lt;/span&gt;: R. N. Clark, G. A. Swayze, R. Wise, K. E. Livo, T. M. Hoefen, R. F. Kokaly, and S. J. Sutley, 2007, USGS Digital Spectral Library splib06a, U.S. Geological Survey, Data Series 231.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4508"/>
        <source> Library Description (requires internet connection)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4533"/>
        <source>Export signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4557"/>
        <source>Export </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4570"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export as CSV file (.csv)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4593"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export as SCP file (*.scp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4600"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Export highlighted spectral signatures&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4621"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a directory where highlighted spectral signatures are saved as .csv&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4651"/>
        <source>Algorithm band weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4684"/>
        <source>Band number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13371"/>
        <source>Band name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4694"/>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4720"/>
        <source>Band weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4948"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Reset&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5153"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4827"/>
        <source>Set weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5137"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="4885"/>
        <source>Automatic  weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5048"/>
        <source>Signature threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5012"/>
        <source>MD Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5017"/>
        <source>ML Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5022"/>
        <source>SAM Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5072"/>
        <source>Set threshold = σ *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5456"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value that will be multiplied by standard deviation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5127"/>
        <source>Set threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5660"/>
        <source>Automatic  thresholds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5245"/>
        <source>LCS threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5298"/>
        <source>Color [overlap MC_ID-C_ID]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5324"/>
        <source>LC Signature threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5338"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Add highlighted signatures to spectral signature plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5383"/>
        <source>Min Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5393"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold Min Max&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5440"/>
        <source>σ *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5523"/>
        <source>From pixel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5533"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activate pointer for setting thresholds from pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5555"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is extended to include pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5572"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is reduced to exclude pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5604"/>
        <source>From ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5614"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set thresholds from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5705"/>
        <source>RGB list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5732"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sort RGB automatically&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5755"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted RGB down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5778"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted RGB up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5828"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export RGB list to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5851"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import RGB list from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5963"/>
        <source>RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="5997"/>
        <source>Automatic RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6025"/>
        <source>Band combinations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6035"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add all combinations of bands&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6084"/>
        <source>Preprocessing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6106"/>
        <source>Landsat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6136"/>
        <source>Directory containing Landsat bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6168"/>
        <source> Landsat conversion to TOA reflectance and brightness temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable calculation of temperature in Celsius from thermal band&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7380"/>
        <source> Brightness temperature in Celsius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7300"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the DOS1 atmospheric correction (thermal band is not corrected)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7303"/>
        <source> Apply DOS1 atmospheric correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7223"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;No data value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7236"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ignore the NoData value in DOS1 calculation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7239"/>
        <source>Use NoData value (image has black border)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6272"/>
        <source>Select MTL file (if not in Landsat directory)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14873"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p  &gt;Select a directory&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6333"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Perform pan-sharpening (Brovey Transform)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6336"/>
        <source>Perform pansharpening (Landsat 7 or 8)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7395"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create the Band set automatically and use the checked Band set tools&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7398"/>
        <source>Create Band set and use Band set tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7417"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit metadata&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7424"/>
        <source>Band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6403"/>
        <source>RADIANCE_MULT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6408"/>
        <source>RADIANCE_ADD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6413"/>
        <source>REFLECTANCE_MULT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6418"/>
        <source>REFLECTANCE_ADD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6423"/>
        <source>RADIANCE_MAXIMUM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6428"/>
        <source>REFLECTANCE_MAXIMUM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6433"/>
        <source>K1_CONSTANT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6438"/>
        <source>K2_CONSTANT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6443"/>
        <source>LMAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6448"/>
        <source>LMIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6453"/>
        <source>QCALMAX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6458"/>
        <source>QCALMIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7115"/>
        <source>Satellite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7553"/>
        <source>Sun elevation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7471"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DATE ACQUIRED&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6570"/>
        <source>Date (YYYY-MM-DD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7501"/>
        <source>Earth sun distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7563"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SUN ELEVATION&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7478"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Earth sun distance&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7632"/>
        <source>Metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6649"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satellite (e.g. LANDSAT8)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6731"/>
        <source>Sentinel-2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6761"/>
        <source>Directory containing Sentinel-2 bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6823"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the DOS1 atmospheric correction&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6904"/>
        <source> Sentinel-2 conversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="6933"/>
        <source>Select metadata file (MTD_SAFL1C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7021"/>
        <source>Quantification value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7026"/>
        <source>Solar irradiance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7092"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Satellite (e.g. Sentinel-2A)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7213"/>
        <source>ASTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7338"/>
        <source> ASTER conversion to TOA reflectance and brightness temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7367"/>
        <source>Select file ASTER L1T (.hdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7429"/>
        <source>UnitConversionCoeff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7434"/>
        <source>PixelSize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7527"/>
        <source>Date (YYYYMMDD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7570"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Upper left (meters)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7593"/>
        <source>UTM zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7603"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;UTM zone&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7655"/>
        <source>UPPERLEFTM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7740"/>
        <source>Clip multiple rasters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13189"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Refresh list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7814"/>
        <source> Raster list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13324"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select Rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7898"/>
        <source>UL Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7911"/>
        <source>LR X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7924"/>
        <source>LR Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7970"/>
        <source> Clip coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="7983"/>
        <source>UL X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8013"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use shapefile boundaries for clipping rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8016"/>
        <source>Use shapefile for clipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8029"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the shapefile for clipping&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8059"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use temporary ROI boundaries for clipping rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8062"/>
        <source>Use temporary ROI for clipping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8078"/>
        <source>NoData value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13001"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;NoData value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8366"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Output name prefix&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8119"/>
        <source>clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8401"/>
        <source>Output name prefix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8257"/>
        <source>Split raster bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8271"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the image to be split&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8300"/>
        <source>Raster input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8329"/>
        <source>Select a multiband raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8369"/>
        <source>split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8497"/>
        <source>PCA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9811"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8537"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, calculate this number of components only&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8540"/>
        <source>Number of components</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8547"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Number of components&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8573"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, NoData value will be ignored during the calculation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9878"/>
        <source>Use NoData value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8693"/>
        <source> Principal Components Analysis of Band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10016"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8754"/>
        <source>Vector to raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8784"/>
        <source>Select the vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11045"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11002"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the value field of the vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11005"/>
        <source>Use the value field of the vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11018"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the value field&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use constant value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10841"/>
        <source>Use constant value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10851"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Value&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8916"/>
        <source>Select the type of conversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8932"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the type of conversion&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="8965"/>
        <source>Select the reference raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9004"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the reference raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9103"/>
        <source>Postprocessing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9123"/>
        <source>Accuracy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9180"/>
        <source>Select the classification to assess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9206"/>
        <source>Select the reference shapefile or raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification to assess&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9303"/>
        <source>Shapefile field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9332"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the field of the classification code &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9451"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Courier 10 Pitch&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9479"/>
        <source>Land cover change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9514"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;If enabled, pixels having the same values in both classifications will be reported; if not enabled, 0 value is set for unchanged pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9517"/>
        <source>Report unchanged pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9533"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the reference classification raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9556"/>
        <source>Select the new classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9588"/>
        <source>Select the reference classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9604"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a new raster to be compared with the reference raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9790"/>
        <source>Classification report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10333"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11843"/>
        <source>Select the classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="9875"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, NoData value will be excluded from the report&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10056"/>
        <source>Classification to vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10564"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the codes from Signature list table for vector symbology&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10567"/>
        <source>Use code from Signature list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10583"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the code field&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10592"/>
        <source>C_ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10587"/>
        <source>MC_ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10622"/>
        <source> Symbology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10287"/>
        <source>Reclassification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10367"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate unique values&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10387"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable this for reclassification from C ID to MC ID; if checked, unique values are calculated from the Signature list, setting old value C ID and new value MC ID&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10390"/>
        <source>calculate C ID to MC ID values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10413"/>
        <source>Calculate unique values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10445"/>
        <source> Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10469"/>
        <source>Old value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10474"/>
        <source>New value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10704"/>
        <source>Edit raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10715"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Undo edit (only for ROI polygons)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10788"/>
        <source>Select the input raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10804"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the raster to edit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10881"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use expression&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10884"/>
        <source>Use expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10909"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter expression&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10912"/>
        <source>where(raster == 1, 2, raster)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="10991"/>
        <source> Edit raster values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11029"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit values using a vector&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11032"/>
        <source> Edit values using a vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11079"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Edit values using temporary ROIs&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11082"/>
        <source> Edit values using ROI polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11112"/>
        <source> Edit options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11128"/>
        <source>Classification sieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11859"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the classification&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11281"/>
        <source>Size threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Size threshold in pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11976"/>
        <source>Pixel connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11998"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pixel connection&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12002"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12007"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11413"/>
        <source>Classification erosion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11915"/>
        <source>Size in pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11925"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Size in pixels&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12035"/>
        <source>Class values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12063"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter class values separated by , or -&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="11762"/>
        <source>Classification dilation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12115"/>
        <source>Band calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13296"/>
        <source> Band list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12164"/>
        <source>Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12191"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse cosine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12194"/>
        <source>acos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12207"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12210"/>
        <source>sin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12223"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse sine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12226"/>
        <source>asin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12239"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cosine&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12242"/>
        <source>cos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12255"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tangent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12258"/>
        <source>tan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12271"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Inverse tangent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12274"/>
        <source>atan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;NoData value of raster (e.g.  nodata(&amp;quot;raster1&amp;quot;) )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12294"/>
        <source>nodata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12309"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Conditional where function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12312"/>
        <source>where</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12325"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exponential&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12328"/>
        <source>exp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12345"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Not equals&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12348"/>
        <source>!=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12361"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Equals&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12364"/>
        <source>==</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12383"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Multiplication&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12386"/>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12399"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Power&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12402"/>
        <source>^</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12415"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minus&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12418"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12431"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Plus&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12434"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12447"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Division&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12450"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12463"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Close parenthesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12466"/>
        <source>)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12479"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Square root&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12482"/>
        <source>√</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12495"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open parenthesis&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12498"/>
        <source>(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12511"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12514"/>
        <source>π</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12527"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Natural logarithm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12530"/>
        <source>ln</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12543"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Greater than&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12546"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12559"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Less than&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12562"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12591"/>
        <source>Index calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12604"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an index&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12651"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter an expression (e.g. &amp;quot;raster1&amp;quot; + &amp;quot;raster2&amp;quot; )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12672"/>
        <source>Decision rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12685"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter one or more rules separated by semicolon (e.g. &amp;quot;raster1&amp;quot; &amp;gt; 0; &amp;quot;raster2&amp;quot; &amp;gt; 0 )&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12692"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12697"/>
        <source>Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12745"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted rule up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12768"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import rules from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12850"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export rules to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted rule down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12929"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="12957"/>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13014"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, pixels equal to NoData value will be excluded from the output raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13017"/>
        <source>Set NoData value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the extent of raster ouput equals the extent of selected raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13027"/>
        <source>Same as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13040"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a raster&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13047"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, the extent of raster ouput equals the intersection of input rasters&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13050"/>
        <source>Intersection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13101"/>
        <source>Extent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13150"/>
        <source>Output raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13179"/>
        <source>Band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13255"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add band to Band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13343"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13376"/>
        <source>Center wavelength</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13381"/>
        <source>Multiplicative Factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13386"/>
        <source>Additive Factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13412"/>
        <source> Band set definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13441"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sort bands by name (priority to ending number)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13464"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted band down&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13487"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move highlighted band up&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13550"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export band set to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13596"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import band set from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13643"/>
        <source> Quick wavelength settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13653"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a configuration for setting band center wavelengths&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13678"/>
        <source>Wavelength unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13688"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wavelength unit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13701"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a virtual raster of band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13704"/>
        <source>Create virtual raster of band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13711"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate expression in Band calc&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13714"/>
        <source>Band calc expressions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13721"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Create a .tif raster stacking the bands of the band set&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13724"/>
        <source>Create raster of band set (stack bands)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Build band overviews (external pyramids) for faster visualization&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13734"/>
        <source>Build band overviews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13757"/>
        <source> Band set tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13980"/>
        <source>Batch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13838"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter a batch function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13899"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a function&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13922"/>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="13991"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Import batch from text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14027"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export batch to text file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14130"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14148"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14169"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Class information field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14195"/>
        <source> Field names of training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14205"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Class ID field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14215"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Macroclass ID field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14238"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set the Macroclass information field name&lt;/p&gt;&lt;p&gt;[max 10 characters]&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14317"/>
        <source> ROI style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14329"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select temporary ROI color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14351"/>
        <source>ROI color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14373"/>
        <source>Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14380"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Change temporary ROI transparency&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14450"/>
        <source> Variable name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14466"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Variable name for expressions&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14469"/>
        <source>raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14495"/>
        <source> Variable name for expressions (tab Reclassification and Edit raster)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14548"/>
        <source>Group name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14564"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Group name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14567"/>
        <source>Class_temp_group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14593"/>
        <source> Temporary group name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14646"/>
        <source> Dock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14656"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, news about the SCP are downloaded on startup and displayed in Dock&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14659"/>
        <source>Download news on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14695"/>
        <source>Processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14703"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the sound when the process is finished&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14706"/>
        <source>Play sound when finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14719"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, create virtual rasters for certain temporary files&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14722"/>
        <source>Use virtual raster for temp files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14745"/>
        <source>Classification process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14752"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, a lossless compression is applied to rasters in order to save disk space&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14755"/>
        <source>Raster compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14785"/>
        <source> RAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14812"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set available RAM for processes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14837"/>
        <source>Available RAM (MB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14850"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reset to default temporary directory&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14912"/>
        <source>Temporary directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14956"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14964"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/Disable the Log of events&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14967"/>
        <source>Record events in a Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="14980"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Export the Log file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15003"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear the Log file content&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15042"/>
        <source> Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15053"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Test dependencies&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15073"/>
        <source>Test dependencies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15112"/>
        <source> Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15152"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin.ui" line="15222"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Developed by &lt;/span&gt;&lt;a href=&quot;http://www.researchgate.net/profile/Luca_Congedo&quot;&gt;&lt;span style=&quot; font-size:10pt; text-decoration: underline; color:#0057ae;&quot;&gt;Luca Congedo&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; (ing.congedoluca@gmail.com), the &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Semi-Automatic Classification Plugin&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; (SCP) is a free open source plugin for QGIS that allows for the semi-automatic classification(also supervised classification) of remote sensing images.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;It provides several tools for the download of free images, the preprocessing, the postprocessing, and the raster calculation.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;For more information and tutorials visit the official site &lt;/span&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;From GIS to Remote Sensing.&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;img src=&quot;:/plugins/semiautomaticclassificationplugin/icons/fromGIStoRS.png&quot; /&gt;&lt;a href=&quot;http://fromgistors.blogspot.com/p/semi-automatic-classification-plugin.html?spref=sacp&quot;&gt;&lt;span style=&quot; font-size:14pt; text-decoration: underline; color:#0000ff;&quot;&gt;From GIS to Remote Sensing&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;a href=&quot;https://www.facebook.com/groups/SemiAutomaticClassificationPlugin&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Semi-Automatic Classification Plugin group on Facebook&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;https://plus.google.com/communities/107833394986612468374&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Semi-Automatic Classification Plugin community on Google+&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-style:italic;&quot;&gt;This plugin requires the installation of GDAL, OGR, Numpy, SciPy, and Matplotlib (already bundled with QGIS).&lt;/span&gt;&lt;/p&gt;
&lt;hr /&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&lt;br /&gt;The Semi-Automatic Classification Plugin is developed by Luca Congedo.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Translators:&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Language: Author&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;justify&quot; style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Semi-Automatic Classification Plugin is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 3 of the License.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Semi-Automatic Classification Plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with Semi-Automatic Classification Plugin. If not, see &amp;lt;&lt;/span&gt;&lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&amp;gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectralSignaturePlot</name>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="20"/>
        <source>SCP: Spectral Signature Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="70"/>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="75"/>
        <source>MC ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="80"/>
        <source>MC Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="85"/>
        <source>C ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="90"/>
        <source>C Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="95"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="124"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Activate pointer for setting thresholds from pixel&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="160"/>
        <source>From pixel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="178"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is reduced to exclude pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="198"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked, signature threshold is extended to include pixel signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="235"/>
        <source>From ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="245"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set thresholds from temporary ROI&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="293"/>
        <source>Automatic  thresholds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold Min Max&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="343"/>
        <source>Min Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="365"/>
        <source>σ *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="381"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set a value that will be multiplied by standard deviation&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="397"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set automatic threshold σ&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="420"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Undo thresholds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="426"/>
        <source>Import library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="449"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p &gt;Delete row&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="592"/>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Add highlighted spectral signatures to signature list&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="495"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Calculate spectral distances&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="544"/>
        <source> Signature list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="841"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Plot the value range (standard deviation or defined minimum and maximum) for each signature&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="623"/>
        <source>Band lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="649"/>
        <source>Max characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="668"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Text lenght of names in the spectral plot legend&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="702"/>
        <source>x=0.000000 y=0.000000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="724"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Change value range interactively in the plot&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="744"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatically fit the plot to data&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="767"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save the plot to file (jpg, png, pdf)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="812"/>
        <source>Plot value range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="844"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="865"/>
        <source>Signature details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_semiautomaticclassificationplugin_signature_plot.ui" line="891"/>
        <source>Spectral distances</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>semiautomaticclassificationplugin</name>
    <message>
        <location filename="semiautomaticclassificationplugin.py" line="1396"/>
        <source>Please, restart QGIS for executing the Semi-Automatic Classification Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="309"/>
        <source>Select a mask shapefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="529"/>
        <source>Save classification output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="625"/>
        <source> conversion to vector. Please wait ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="721"/>
        <source>Select a qml style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="791"/>
        <source>Select a signature list file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="805"/>
        <source>Select a SCP training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1115"/>
        <source>Export SCP training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1190"/>
        <source>Select a library file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1219"/>
        <source>Export the highlighted signatures to CSV library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1292"/>
        <source>Calculate signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1292"/>
        <source>Calculate signatures for highlighted items?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1318"/>
        <source>Merge signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1318"/>
        <source>Merge highlighted signatures?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="468"/>
        <source>Delete signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="1439"/>
        <source>Are you sure you want to delete highlighted ROIs and signatures?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2031"/>
        <source>Create SCP training input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2143"/>
        <source>Add required fds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2143"/>
        <source>It appears that the shapefile </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2143"/>
        <source> is missing some fields that are required for the signature calculation. 
Do you want to add the required fields to this shapefile?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2227"/>
        <source>Undo save ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classificationdock.py" line="2227"/>
        <source>Are you sure you want to delete the last saved ROI?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="134"/>
        <source>Semi-Automatic Classification Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="138"/>
        <source>Zoom to input image extent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="140"/>
        <source>Show/hide the input image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="146"/>
        <source>Select a RGB color composite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="149"/>
        <source>Local cumulative cut stretch of band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="151"/>
        <source>Local standard deviation stretch of band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="153"/>
        <source>Zoom to temporary ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="155"/>
        <source>Show/hide the temporary ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="157"/>
        <source>Create a ROI polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="159"/>
        <source>Activate ROI pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="161"/>
        <source>Redo the ROI at the same point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="164"/>
        <source> Dist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="165"/>
        <source>Similarity of pixels (distance in radiometry unit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="167"/>
        <source> Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="168"/>
        <source>Minimum area of ROI (in pixel unit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="170"/>
        <source> Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="171"/>
        <source>Side of a square which inscribes the ROI, defining the maximum width thereof (in pixel unit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="173"/>
        <source>Zoom to the classification preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="175"/>
        <source>Show/hide the classification preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="177"/>
        <source>Activate classification preview pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="178"/>
        <source>Redo the classification preview at the same point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="181"/>
        <source> T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="182"/>
        <source>Set preview transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="184"/>
        <source> S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="185"/>
        <source>Set the preview size (in pixel unit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="186"/>
        <source>Remove temporary files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="312"/>
        <source>Band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="314"/>
        <source>Download images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="322"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="338"/>
        <source>Preprocessing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="354"/>
        <source>Postprocessing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="374"/>
        <source>Band calc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="376"/>
        <source>Spectral plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="378"/>
        <source>Scatter plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="380"/>
        <source>Batch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="382"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="399"/>
        <source>User manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="401"/>
        <source>Online help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="308"/>
        <source>SCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="73"/>
        <source>Test results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="133"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="76"/>
        <source>Default ROI style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="79"/>
        <source>No log file found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="82"/>
        <source>Select a SCP training input; input is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="85"/>
        <source>Select a raster; raster is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="88"/>
        <source>Select a point inside the image area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="91"/>
        <source>No file found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="94"/>
        <source>Data projections do not match. Reproject data to the same projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="97"/>
        <source>Maximum Likelihood threshold must be less than 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="100"/>
        <source>Spectral Angle Mapping threshold must be less than 90</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="103"/>
        <source>Select a classification output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="splitTab.py" line="79"/>
        <source>Select a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="109"/>
        <source>Restart QGIS for the new settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="112"/>
        <source>At least 3 points are required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="115"/>
        <source>Negative IDs are not allowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="118"/>
        <source>Select at least one signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="121"/>
        <source>SCP is recording the Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="124"/>
        <source>Signature list file (.slf) created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="127"/>
        <source>No image found. Try with a larger area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="130"/>
        <source>Create a ROI polygon or use a vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="133"/>
        <source>Define a search area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="310"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="137"/>
        <source>Classification failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="140"/>
        <source>ROI creation failed. <byte value="xd"/>
or <byte value="xd"/>
Possible reason: one or more band of the band set are missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="146"/>
        <source>Signature calculation failed. <byte value="xd"/>
Possible reason: the raster is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="149"/>
        <source>Import failed. <byte value="xd"/>
Possible reason: selected file is not a band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="152"/>
        <source>Classification failed. <byte value="xd"/>
It appears the one or more bands of the band set are missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="155"/>
        <source>ROI creation failed. <byte value="xd"/>
Possible reason: input is a virtual raster or band is not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="158"/>
        <source>No metadata found inside the input directory (a .txt file whose name contains MTL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="161"/>
        <source>Raster not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="164"/>
        <source>Raster not found or clip failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="167"/>
        <source>Shapefile or raster not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="170"/>
        <source>Error deleting ROI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="173"/>
        <source>The Macroclass field is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="176"/>
        <source>Error saving signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="179"/>
        <source>Error opening signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="182"/>
        <source>Error opening spectral library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="185"/>
        <source>Error saving spectral library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="188"/>
        <source>Import failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="191"/>
        <source>ROI creation failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="194"/>
        <source>Internet connection failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="197"/>
        <source>Exporting Log file failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="200"/>
        <source>Saving algorithm files failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="203"/>
        <source>Unable to get ROI attributes; check training shapefiles field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="209"/>
        <source>Error reading raster. Possibly the raster path contains unicode characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="212"/>
        <source>The version of Numpy is outdated. Please install QGIS using OSGEO4W for an updated version of Numpy or visit http://fromgistors.blogspot.com/p/frequently-asked-questions.html#numpy_version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="215"/>
        <source>Unable to perform operation. Possibly OGR is missing drivers. Please repeat QGIS installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="218"/>
        <source>Memory error. Please, set a lower value of RAM in the tab Settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="221"/>
        <source>Edge error. Reduce the ROI width or draw a ROI manually (recommended installation of GDAL &gt;= 1.10)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="224"/>
        <source>Unable to proceed. Rename the Landsat bands with a file name ending with the band number (e.g. rename B20 to B2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="227"/>
        <source>Error calculating signature. Possibly ROI is too small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="230"/>
        <source>Unable to split bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="233"/>
        <source>Error reading band set. Possibly raster files are not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="236"/>
        <source>Clip area outside image. Check the raster projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="239"/>
        <source>Unable to merge. Signatures have different unit or wavelength</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="242"/>
        <source>Unable to calculate. Expression error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="245"/>
        <source>Unable to calculate. Metadata error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="251"/>
        <source>Unable to find images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="254"/>
        <source>Unable to connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="257"/>
        <source>Unable to load image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="263"/>
        <source>Attribute table error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="266"/>
        <source>Unable to pansharpen: missing bands </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="269"/>
        <source>Unable to calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="272"/>
        <source>Error reading raster. Possibly bands are not aligned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="275"/>
        <source>Unable to get raster projection. Try to reproject the raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="278"/>
        <source>Error calculating accuracy. Possibly shapefile polygons are outside classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="281"/>
        <source>Unable to connect. Check user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="287"/>
        <source>No metadata found inside the input directory (a .xml file whose name contains MTD_L1C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="290"/>
        <source>No metadata found inside the input directory (a .xml file whose name contains MTD_SAFL1C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="293"/>
        <source>Memory error. Please, decrease decimal precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="296"/>
        <source>Error calculating plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="302"/>
        <source>SSL connection error. Please see the FAQ of the plugin user manual for solving this</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="364"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="309"/>
        <source>It appears that SciPy is not correctly installed. Please, update QGIS </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="312"/>
        <source>It appears that SciPy is not correctly installed. Please, see this page for information about SciPy installation </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="315"/>
        <source>rasters have different pixel sizes that can lead to incorrect results. Please, consider to resample rasters to the same pixel size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="318"/>
        <source>The same ID class has been already assigned to a different macrolass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="321"/>
        <source>Wavelength already present</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="324"/>
        <source>Wavelength unit not provided in band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="334"/>
        <source>RAM value was too high. Value has been decreased automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="340"/>
        <source>Unable to load the virtual raster. Please create it manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="343"/>
        <source>Unable to proceed. The raster must be in projected coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="346"/>
        <source>Select at least one raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="349"/>
        <source>Incorrect expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="352"/>
        <source>Unable to access the temporary directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="355"/>
        <source>Reduce the search area extent within 10 degrees of latitude and 10 degrees of longitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="358"/>
        <source>Macroclass symbology is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="361"/>
        <source>Missing bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="messages.py" line="364"/>
        <source>No metadata found inside the input directory. Default values will be used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="signature_importer.py" line="191"/>
        <source>Select a shapefile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="utils.py" line="2125"/>
        <source>Please wait ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1161"/>
        <source>Set thresholds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1161"/>
        <source>Are you sure you want to set thresholds for several signatures?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="67"/>
        <source>Save error matrix raster output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="277"/>
        <source>Classification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="277"/>
        <source>ErrMatrixCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="297"/>
        <source>Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>PixelSum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="296"/>
        <source>ERROR MATRIX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="310"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="319"/>
        <source>Overall accuracy [%] = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="333"/>
        <source>Class </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="333"/>
        <source> producer accuracy [%] = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="333"/>
        <source> user accuracy [%] = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="333"/>
        <source>Kappa hat = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="accuracy.py" line="336"/>
        <source>Kappa hat classification = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="algorithmWeightTab.py" line="84"/>
        <source>Reset weights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="algorithmWeightTab.py" line="84"/>
        <source>Are you sure you want to reset weights?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="asterTab.py" line="46"/>
        <source>Select a HDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="99"/>
        <source>Clear rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="99"/>
        <source>Are you sure you want to clear the rules?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="175"/>
        <source>Select a text file of rules</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandcalcTab.py" line="209"/>
        <source>Save the rules to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vectortorasterTab.py" line="65"/>
        <source>Save raster output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="152"/>
        <source>Select a raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="306"/>
        <source>Clear band set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="306"/>
        <source>Are you sure you want to clear the band set?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="484"/>
        <source>Save the band set to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="517"/>
        <source>Select a band set file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="764"/>
        <source>Remove band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="764"/>
        <source>Are you sure you want to remove the selected bands from band set?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="812"/>
        <source>Save virtual raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="833"/>
        <source>Save raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="884"/>
        <source>Build overviews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="884"/>
        <source>Do you want to build the external overviews of bands?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="bandsetTab.py" line="897"/>
        <source> building overviews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batchTab.py" line="119"/>
        <source>Select a batch file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batchTab.py" line="126"/>
        <source>Save the batch to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="47"/>
        <source>Save classification report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="54"/>
        <source>report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="85"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="111"/>
        <source>Class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classreportTab.py" line="111"/>
        <source>Percentage %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="classtovectorTab.py" line="61"/>
        <source>Save shapefile output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clipmultiplerasters.py" line="128"/>
        <source>Select a directory where to save clipped rasters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sieveTab.py" line="51"/>
        <source>Save output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="557"/>
        <source>Searching ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="337"/>
        <source>Download the images in the table (requires internet connection)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="482"/>
        <source>Export download links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="634"/>
        <source>Reset signature list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="downloadsentinelimages.py" line="634"/>
        <source>Are you sure you want to clear the table?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="102"/>
        <source>Save land cover change raster output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>ChangeCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>ReferenceClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landcoverchange.py" line="198"/>
        <source>NewClass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="landsatTab.py" line="54"/>
        <source>Select a MTL file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="multipleroiTab.py" line="214"/>
        <source>Save the point list to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="180"/>
        <source>Principal Components Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="182"/>
        <source>Covariance matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="205"/>
        <source>Bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="194"/>
        <source>Correlation matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="203"/>
        <source>Eigen vectors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="207"/>
        <source>Vector_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="215"/>
        <source>Eigen values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="215"/>
        <source>Accounted variance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pcaTab.py" line="215"/>
        <source>Cumulative variance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="129"/>
        <source>Reset RGB list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="129"/>
        <source>Are you sure you want to clear the RGB list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="218"/>
        <source>RGB list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="218"/>
        <source>Calculate all the RGB combinations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="rgblistTab.py" line="243"/>
        <source>Save the RGB list to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sentinelTab.py" line="54"/>
        <source>Select a XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="250"/>
        <source>Transparency </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="72"/>
        <source>Save Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="187"/>
        <source>Reset field names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="187"/>
        <source>Are you sure you want to reset field names?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="198"/>
        <source>Reset variable name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="198"/>
        <source>Are you sure you want to reset variable name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="206"/>
        <source>Reset group name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="206"/>
        <source>Are you sure you want to reset group name?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="214"/>
        <source>Change temporary directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="214"/>
        <source>Are you sure you want to change the temporary directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="235"/>
        <source>Reset temporary directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.py" line="235"/>
        <source>Are you sure you want to reset the temporary directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="signatureThresholdTab.py" line="120"/>
        <source>Reset thresholds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="signatureThresholdTab.py" line="120"/>
        <source>Are you sure you want to reset thresholds?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scatter_plot.py" line="484"/>
        <source>Delete scatter plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="scatter_plot.py" line="484"/>
        <source>Are you sure you want to delete highlighted scatter plots?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="206"/>
        <source>Save plot to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="87"/>
        <source>Edit value range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="87"/>
        <source>Are you sure you want to edit the value range for several signatures?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="233"/>
        <source>Add to Signature list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="233"/>
        <source>Are you sure you want to add highlighted signatures to the list?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="468"/>
        <source>Are you sure you want to delete highlighted signatures?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="625"/>
        <source>Values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1033"/>
        <source>Undo thresholds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="spectralsignatureplot.py" line="1033"/>
        <source>Are you sure you want to undo thresholds?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="semiautomaticclassificationplugin.py" line="361"/>
        <source>Please, restart QGIS for executing the Semi-Automatic Classification Plugin. Possible missing dependecies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="316"/>
        <source>Landsat download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="318"/>
        <source>Sentinel-2 download </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="324"/>
        <source>Multiple ROI creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="326"/>
        <source>Import signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="328"/>
        <source>Export signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="330"/>
        <source>Algorithm band weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="332"/>
        <source>Signature threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="334"/>
        <source>LCS threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="340"/>
        <source>Landsat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="342"/>
        <source>Sentinel-2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="344"/>
        <source>ASTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="346"/>
        <source>Clip multiple rasters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="348"/>
        <source>Split raster bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="350"/>
        <source>PCA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="352"/>
        <source>Vector to raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="356"/>
        <source>Accuracy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="358"/>
        <source>Land cover change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="360"/>
        <source>Classification report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="362"/>
        <source>Classification to vector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="364"/>
        <source>Reclassification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="366"/>
        <source>Edit raster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="368"/>
        <source>Classification sieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="370"/>
        <source>Classification erosion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="372"/>
        <source>Classification dilation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="403"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="320"/>
        <source>ASTER download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="384"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="389"/>
        <source>Processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="input.py" line="394"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
